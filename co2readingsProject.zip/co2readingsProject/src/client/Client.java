import java.io.*;
import java.net.*;

public class Client {
    private final String serverIp;
    private final int port;

    public Client(String serverIp, int port) {
        this.serverIp = serverIp;
        this.port = port;
    }

    public void start() {
        try (Socket socket = new Socket(serverIp, port);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader console = new BufferedReader(new InputStreamReader(System.in))
        ) {
            System.out.println("Connected to server.");

            // Read and display server messages
            System.out.println(in.readLine()); // Welcome message

            // Read prompts, provide inputs, and send to server
            System.out.println(in.readLine()); // Prompt for User ID
            String userId = console.readLine();
            out.println(userId);

            System.out.println(in.readLine()); // Prompt for Postcode
            String postcode = console.readLine();
            out.println(postcode);

            System.out.println(in.readLine()); // Prompt for CO2 concentration
            String co2 = console.readLine();
            out.println(co2);

            // Read confirmation message from the server
            System.out.println(in.readLine());

        } catch (IOException e) {
            System.out.println("Client error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        String serverIp = args.length > 0 ? args[0] : "127.0.0.1";
        int port = args.length > 1 ? Integer.parseInt(args[1]) : 8080;

        Client client = new Client(serverIp, port);
        client.start();
    }
}
